package A4.app;

import java.io.IOException;
import java.util.Scanner;

public class CRUD {
	public static void main(String[] args) {

		Scanner input = new Scanner(System.in);
		String choice, cont = "y";
		{

			while (cont.equalsIgnoreCase("y")) {
				System.out.println("\t\t Member information System\n\n");

				System.out.println("1 ===> Add New Employee Record ");
				System.out.println("2 ===> View All Employee Record ");
				System.out.println("3 ===> Delete Employee Record ");
				System.out.println("4 ===> Search Specific Record ");
				System.out.println("5 ===> Update Specific Record ");

				System.out.print("\n\n");
				System.out.println("Enter your choice: ");
				choice = input.nextLine();

				if (choice.equals("1")) {
					try {
						naldrixClass.AddRecord();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				} else if (choice.equals("2")) {
					try {
						naldrixClass.ViewAllRecord();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				} else if (choice.equals("3")) {
					try {
						naldrixClass.DeleteRecordByID();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				} else if (choice.equals("4")) {
					try {
						naldrixClass.SearchRecordbyID();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				} else if (choice.equals("5")) {
					try {
						naldrixClass.updateRecordbyID();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}

				System.out.println("Do you want to continue? Y/N");
				cont = input.nextLine();

			}

		}
	}
}